package granjas.granja;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GranjaApplicationTests {

	@Test
	void contextLoads() {
	}

}
